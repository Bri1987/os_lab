#include "syscalls.h"
extern void CHANGE_MODE();
extern void IN_SVC();

INT8U OSTaskCreate_syscall(void (*task)(void *p_arg),void *p_arg,OS_STK *ptos,INT8U prio)
{
	INT8U err=OS_ERR_NONE;
	IN_SVC();
	OSTCBCur->OSTCBRunLevel=1;
	(void)OSTaskCreateExt(task,
                          (void *)0,ptos,prio, 13,&ptos[0], 128,(void *)0,                
                          OS_TASK_OPT_STK_CHK | OS_TASK_OPT_STK_CLR,1);
	CHANGE_MODE();
	return err;
}

INT8U OSTaskSuspend_syscall(INT8U prio)
{
	INT8U err=OS_ERR_NONE;
	IN_SVC();
	OSTaskSuspend(prio);
	CHANGE_MODE();
	return err;
}

void OSMutexPend_syscall(OS_EVENT *prevent,INT32U timeout,INT8U *perr)
{
	IN_SVC();
	OSMutexPend(prevent,timeout,perr);
	CHANGE_MODE();
}

INT8U OSMutexPost_syscall(OS_EVENT *prevent)
{
	INT8U err=OS_ERR_NONE;
	IN_SVC();
	OSMutexPost(prevent);
	CHANGE_MODE();
	return err;
}

void OSTimeDly_syscall(INT32U ticks)
{
	IN_SVC();
	OSTimeDly(ticks);
	CHANGE_MODE();
}
