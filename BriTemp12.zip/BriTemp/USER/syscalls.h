#ifndef __SYSCALLS_H
#define __SYSCALLS_H

#include "includes.h"

INT8U OSTaskCreate_syscall(void (*task)(void *p_arg),void *p_arg,OS_STK *ptos,INT8U prio);
INT8U OSTaskSuspend_syscall(INT8U prio);
void OSMutexPend_syscall(OS_EVENT *prevent,INT32U timeout,INT8U *perr);
INT8U OSMutexPost_syscall(OS_EVENT *prevent);
void OSTimeDly_syscall(INT32U ticks);
#endif
