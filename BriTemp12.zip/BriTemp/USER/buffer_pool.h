#define NUM_BUFFERS 10
#define BUFFER_SIZE 100

struct BufferPool {
    char Buffer[NUM_BUFFERS][BUFFER_SIZE];
    int Index[NUM_BUFFERS];
};