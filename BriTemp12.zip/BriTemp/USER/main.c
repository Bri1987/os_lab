#include "includes.h"
#include "sys.h"
#include "usart.h"
#include "delay.h"
#include "syscalls.h"

OS_EVENT *mutex;

#define TASK1_PRIO 5
#define TASK2_PRIO 6
#define TASK1_STK_SIZE 128
#define TASK2_STK_SIZE 128
OS_STK TASK1_TASK_STK[TASK1_STK_SIZE];
OS_STK TASK2_TASK_STK[TASK2_STK_SIZE];
void task1(void *pdata);
void task2(void *pdata);

int main()
{
	delay_init(168);
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	uart_init(115200);
	OSInit();
	OSStart();
}

void start_task(void *pdata)
{
	u8 err;
	OS_CPU_SR cpu_sr=0;
	mutex=OSMutexCreate(0,&err);
	OS_ENTER_CRITICAL();
	OSTaskCreate_syscall(task1,(void*)0,(OS_STK*)&TASK1_TASK_STK[TASK1_STK_SIZE-1],TASK1_PRIO);
	OSTaskCreate_syscall(task2,(void*)0,(OS_STK*)&TASK2_TASK_STK[TASK2_STK_SIZE-1],TASK2_PRIO);
	OSTaskSuspend_syscall(10);
	OS_EXIT_CRITICAL();
}

void task1(void *pdata)
{
	u8 err;
	int j=0;
	for(;j<20;j++){
		OSMutexPend_syscall(mutex,0,&err);
		OSTimeDlyHMSM(0,0,0,100);
		printf("1111111111111\n");
		OSMutexPost_syscall(mutex);
	}
}

void task2(void *pdata)
{
	u8 err;int i=0;
	for(;i<20;i++){
		OSMutexPend_syscall(mutex,0,&err);
		OSTimeDlyHMSM(0,0,0,100);
		printf("2222222222222 \n");
		OSMutexPost_syscall(mutex);
	}
}



